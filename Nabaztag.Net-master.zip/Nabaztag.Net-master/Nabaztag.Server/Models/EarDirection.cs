﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nabaztag.Server.Models
{
    public enum  EarDirection
    {
        Forward = 0,
        Backward = 1,
    }
}
