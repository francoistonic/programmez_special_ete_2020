// eslint-disable-next-line import/prefer-default-export
export const colorError = '#b71c1c';
export const colorWarning = '#e65100';
export const colorInfo = '#1b5e20';
