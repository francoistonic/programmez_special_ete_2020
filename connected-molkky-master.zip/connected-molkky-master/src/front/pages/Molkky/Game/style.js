export default {
  loadingBar: {
    height: 'auto',
    position: 'absolute',
    top: 56,
  },
  loadingBarProgress: {
    margin: 0,
  },
};
