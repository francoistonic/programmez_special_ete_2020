export default {
  container: {
    background: '#fff',
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100%',
    height: '2.2rem',
    zIndex: 10,
  },

  progressBar: {
    height: '1rem',
  },
};
