export default {
  menu_medium_up: {
    marginTop: '0.4rem',
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gridGap: '1rem',
  },
};
