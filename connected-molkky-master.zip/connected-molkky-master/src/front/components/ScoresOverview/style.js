export default {
  container: { marginTop: '1rem' },
};
