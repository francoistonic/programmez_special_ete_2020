export default {
  container: {
    display: 'flex',
    flexDirection: 'column',
    marginBottom: '2rem',
  },
  row: {
    display: 'flex',
    justifyContent: 'center',
  },
  hover: { cursor: 'pointer' },
};
