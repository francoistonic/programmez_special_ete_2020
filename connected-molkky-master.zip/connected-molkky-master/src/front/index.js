import App from './App';

export default new App().init();
